Hey! This is my font. It's a bitmap of my own handwriting. 

Feel free to use it for stuff - if you aren't making money or if you're using it for educational purposes, that's fine. If it's for a commercial thing then just lmk. I'll probably be cool with it, but you never know.

Find me through thermitefe8@gmail.com and visit my portfolio site at https://thermitefe8.github.io/